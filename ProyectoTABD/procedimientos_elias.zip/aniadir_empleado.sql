SET SERVEROUTPUT;

CREATE OR REPLACE PROCEDURE aniadir_empleado
(
		p_cod_emp IN Tabla_Empleados.cod_emp%TYPE,
		p_nombre IN Tabla_Empleados.nombre%TYPE,
		p_apellidos IN Tabla_Empleados.apellidos%TYPE,
		p_sueldo IN Tabla_Empleados.sueldo%TYPE,
		p_jornada_laboral IN Tabla_Empleados.jornada_laboral%TYPE,
		p_direccion IN Tabla_Empleados.direccion%TYPE,
		p_telfs IN Tabla_Empleados.telfs%TYPE,
		p_tipo IN Tabla_Empleados.tipo%TYPE
)AS 
BEGIN
	
	IF LOWER(p_tipo) = 'mantenimiento' THEN
	
	INSERT INTO Tabla_Empleados
	VALUES (Tipo_Mantenimiento(p_cod_emp,p_suelo,p_nombre,p_apellidos,p_jornada_laboral,p_direccion,p_telfs,p_tipo,NULL));
	
	END IF;
	
	IF LOWER(p_tipo) = 'jefe' THEN
	
	INSERT INTO Tabla_Empleados
	VALUES (Tipo_Jefe(p_cod_emp,p_suelo,p_nombre,p_apellidos,p_jornada_laboral,p_direccion,p_telfs,p_tipo,NULL));
	
	END IF;

	IF LOWER(p_tipo) = 'monitor' THEN
	
	INSERT INTO Tabla_Empleados
	VALUES (Tipo_Monitor(p_cod_emp,p_suelo,p_nombre,p_apellidos,p_jornada_laboral,p_direccion,p_telfs,p_tipo,NULL));
	END IF;
	END aniadir_empleado;