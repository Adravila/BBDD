SET SERVEROUTPUT;

CREATE OR REPLACE PROCEDURE asignar_rutina_cliente
(
	p_dni Tabla_Clientes.dni_e%TYPE,
	p_cod_rutina Tabla_Rutinas.cod_rutina%TYPE,
	p_proposito Tabla_Rutinas.proposito%TYPE,
	p_duracion Tabla_Rutinas.duracion%TYPE,
	p_ref_monitor REF Tipo_Monitor
)
AS 
	aux REF Tipo_Cliente;
BEGIN
		SELECT REF(P) INTO aux
		FROM Tabla_Clientes P
		WHERE p_dni = P.dni_e;

		INSERT INTO Tabla_Rutinas -- Los ejercicios se asignan posteriormente a elecci�n propia del cliente en otro procedimiento.
		VALUES (Tipo_Rutina(p_cod_rutina,p_proposito,p_duracion,Tipo_A_E_C(aux),NULL,p_ref_monitor));
		DMBS_OUTPUT.PUT_LINE('Rutina creada y asignada al cliente.');
		
END asignar_rutina_cliente;