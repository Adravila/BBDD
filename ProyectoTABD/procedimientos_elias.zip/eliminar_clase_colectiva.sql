SET SERVEROUTPUT;

CREATE OR REPLACE PROCEDURE eliminar_clase_colectiva
(
		p_fecha IN Tabla_ClasesColectivas.fecha%TYPE
)AS 
BEGIN

	DELETE FROM Tabla_ClasesColectivas P
	WHERE P.fecha = p_fecha;
	
END eliminar_clase_colectiva;