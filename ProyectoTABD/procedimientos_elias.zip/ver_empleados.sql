SET SERVEROUTPUT;

CREATE OR REPLACE PROCEDURE ver_empleados AS 

CURSOR c_cursor IS 
	(SELECT * FROM Tabla_Empleados);
BEGIN
	FOR r_cursor IN c_cursor LOOP
		DMBS_OUTPUT.PUT_LINE('El nombre del cliente es: '||r_cursor.nombre||' '||r_cursor.apellidos||' y su tipo es '||r_cursor.tipo||'.');
	END LOOP;
END ver_empleados;