SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE ver_equipo_clase_colectiva 
(
	p_fecha Tabla_ClasesColectivas.fecha%TYPE
)
AS 
tabla utiliza;
BEGIN
	
	SELECT utiliza INTO tabla
	FROM Tabla_ClasesColectivas T
	WHERE T.fecha=p_fecha;
	
	DMBS_OUTPUT.PUT_LINE('El equipo que utiliza la clase que sera en :'||p_fecha||' sera: ' );
	FOR i IN 1 .. tabla.count LOOP
		DMBS_OUTPUT.PUT_LINE(DEREF(tabla(i)).cod_equipo);
	END LOOP;
	
END ver_equipo_clase_colectiva;