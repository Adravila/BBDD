SET SERVEROUTPUT;

CREATE OR REPLACE PROCEDURE ver_clientes AS 

CURSOR c_cursor IS 
	(SELECT * FROM Tabla_Clientes);
BEGIN
	FOR r_cursor IN c_cursor LOOP
		DMBS_OUTPUT.PUT_LINE('El nombre del cliente es: '||r_cursor.nombre||' '||r_cursor.apellidos||' y su dni es '||r_cursor.dni_e||'.');
	END LOOP;
END ver_clientes;