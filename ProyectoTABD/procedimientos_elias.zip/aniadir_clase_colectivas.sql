SET SERVEROUTPUT;

CREATE OR REPLACE PROCEDURE aniadir_clase_colectiva
(
		p_fecha IN Tabla_ClasesColectivas.fecha%TYPE,
		p_duracion IN Tabla_ClasesColectivas.duracion%TYPE,
		p_tipo_clase IN Tabla_ClasesColectivas.tipo_clase%TYPE,
)AS 
BEGIN
	INSERT INTO Tabla_ClasesColectivas
	VALUES (Tipo_ClaseColectiva(p_fecha,p_duracion,p_tipo_clase,NULL)); -- EN principio, el cliente no tiene ningun monitor asignado.
END aniadir_clase_colectiva;