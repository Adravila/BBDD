SET SERVEROUTPUT;

CREATE OR REPLACE PROCEDURE eliminar_empleado
(
		p_cod IN Tabla_Empleados.cod_emp%TYPE,
		p_type IN Tabla_Empleados.tipo%TYPE
)AS 
BEGIN
	DELETE FROM Tabla_Empleados P
	WHERE P.cod_emp = p_cod;
END eliminar_empleado;