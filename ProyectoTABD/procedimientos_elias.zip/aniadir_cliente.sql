SET SERVEROUTPUT;

CREATE OR REPLACE PROCEDURE aniadir_cliente
(
		p_dni IN Tabla_Clientes.dni_e%TYPE,
		p_nombre IN Tabla_Clientes.nombre%TYPE,
		p_apellidos IN Tabla_Clientes.apellidos%TYPE,
		p_peso IN Tabla_Clientes.direccion%TYPE,
		p_suscripcion IN Tabla_Clientes.suscripcion%TYPE,
		p_telfs IN Tabla_Clientes.telfs%TYPE,
		p_direccion IN Tabla_Clientes.direccion%TYPE
)AS 
BEGIN
	INSERT INTO Tabla_Clientes
	VALUES (Tipo_Cliente(p_dni,p_nombre,p_apellidos,p_telfs,p_peso,p_direccion,p_suscripcion,NULL)); -- EN principio, el cliente no tiene ningun monitor asignado.
END aniadir_cliente;