SET SERVEROUTPUT;

CREATE OR REPLACE PROCEDURE eliminar_cliente
(
		p_dni IN Tabla_Clientes.dni_e%TYPE
)AS 
BEGIN
	DELETE FROM Tabla_Clientes P
	WHERE P.dni_e = p_dni;
END eliminar_cliente;