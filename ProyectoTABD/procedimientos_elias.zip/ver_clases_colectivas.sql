SET SERVEROUTPUT;

CREATE OR REPLACE PROCEDURE ver_clases_colectivas AS 

CURSOR c_cursor IS 
	(SELECT * FROM Tabla_ClasesColectivas);
BEGIN
	FOR r_cursor IN c_cursor LOOP
		DMBS_OUTPUT.PUT_LINE('La clase colectiva: '||r_cursor.tipo_clase||' tiene lugar en '||r_cursor.fecha||' y su duracion es '||r_cursor.duracion||'.');
	END LOOP;
END ver_clases_colectivas;